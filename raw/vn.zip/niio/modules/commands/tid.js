module.exports.config = {
	name: "tid",
	version: "1.1.0",
	hasPermssion: 0,
	credits: "NTKhang • patched by GPT",
	description: "Trả về ID box hiện tại",
	commandCategory: "Nhóm",
	cooldowns: 0,
	usePrefix: false // ✅ Cho phép gọi trực tiếp không cần tiền tố
};

module.exports.run = async function ({ api, event }) {
	// Nếu người dùng chỉ gửi tin nhắn là 'tid' (không có prefix) → phản hồi TID
	if (event.body && event.body.trim().toLowerCase() === "tid") {
		return api.sendMessage(`${event.threadID}`, event.threadID, event.messageID);
	}
};
