
module.exports.config = {
    name: "shortcut",
    version: "4.2.0",
    hasPermssion: 1,
    credits: "Niio-team (Niiozic) + patched by ChatGPT",
    description: "Shortcut full chức năng",
    commandCategory: "Tiện ích",
    usages: "[all/delete/empty/tag/join/leave/autosend]\n{time} -> get time\n{name} -> get name user\n{nameThread} -> get name box\n{soThanhVien} -> get số thành viên nhóm\n{link} -> get link user\n{authorName} -> get name người add or kick\n{authorId} -> get link người add or kick\n{trangThai} -> lúc out sẽ hiện tự out or bị qtv kick\n{qtv} -> có tv tham gia hoặc out sẽ tag toàn bộ qtv",
    cooldowns: 0,
    dependencies: {
        "fs-extra": "",
        "path": "",
        "axios": "",
        "moment-timezone": "",
        "form-data": ""
    }
};

global.nodemodule = {
    "path": require("path"),
    "fs": require("fs"),
    "fs-extra": require("fs-extra")
};

const axios = require('axios');
const moment = require('moment-timezone');
const FormData = require('form-data');
const urlLib = require('url');

// Robust stream fetcher
const stream_url = async (url) => {
  const res = await axios.get(url, {
    responseType: 'stream',
    timeout: 20000,
    maxRedirects: 5,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121 Safari/537.36'
    },
    validateStatus: s => s >= 200 && s < 400
  });
  const stream = res.data;
  try {
    const pathname = urlLib.parse(url).pathname || '';
    const ext = (pathname.split('.').pop() || 'mp4').split('?')[0];
    if (!stream.path) stream.path = `random.${ext}`;
  } catch {}
  return stream;
};

const { readFileSync, writeFileSync } = require('fs');
const { resolve } = global.nodemodule["path"];
const shortcutJsonPath = resolve(__dirname, '..', 'commands', `data`, "shortcutdata.json");

// ===== Random videos from single JSON: bot/listapi/video/vdgai.json =====
const fsx = require('fs');
const RANDOM_JSON_PATH = require('path').resolve(process.cwd(), 'bot', 'listapi', 'video', 'vdgai.json');

function normalizeVideoList(raw) {
    if (!raw) return [];
    if (Array.isArray(raw)) {
      return raw.map(x => {
        if (typeof x === 'string') return x;
        if (x && typeof x.url === 'string') return x.url;
        return null;
      }).filter(x => typeof x === 'string' && /^https?:\/\//i.test(x));
    }
    if (raw && Array.isArray(raw.links)) {
      return raw.links.map(x => (typeof x === 'string' ? x : (x && x.url)))
        .filter(x => typeof x === 'string' && /^https?:\/\//i.test(x));
    }
    return [];
}

function loadRandomVideos() {
    try {
        const txt = fsx.readFileSync(RANDOM_JSON_PATH, 'utf-8');
        const json = JSON.parse(txt);
        const list = normalizeVideoList(json);
        global.randomVideos = list;
        console.log(`[shortcut] Loaded ${list.length} media from ${RANDOM_JSON_PATH}`);
    } catch (e) {
        console.warn(`[shortcut] Cannot load ${RANDOM_JSON_PATH}: ${e.message}`);
        if (!Array.isArray(global.randomVideos)) global.randomVideos = [];
    }
}

// lần đầu nạp và watch file thay đổi
loadRandomVideos();
try {
    fsx.watchFile(RANDOM_JSON_PATH, { interval: 1500 }, () => {
        try { loadRandomVideos(); } catch { }
    });
} catch (e) {
    console.warn('[shortcut] watchFile not available:', e.message);
}

// Helpers
function randPick(arr) { return arr[(Math.random() * arr.length) << 0]; }

async function pickRandomMedia() {
    if (Array.isArray(global.randomVideos) && global.randomVideos.length) {
        const tried = new Set();
        for (let tries = 0; tries < 5; tries++) {
            const url = randPick(global.randomVideos);
            if (tried.has(url)) continue;
            tried.add(url);
            try {
                return [await stream_url(url)];
            } catch (e) {
                // try another url
            }
        }
        return null; // let caller fallback to showing URL text
    }
    if (Array.isArray(global.girl) && global.girl.length) return global.girl.splice(0, 1);
    if (Array.isArray(global.trai) && global.trai.length) return global.trai.splice(0, 1);
    return null;
}

module.exports.onLoad = function ({ api }) {
    const { existsSync, writeFileSync, readFileSync } = global.nodemodule["fs-extra"];
    if (!global.moduleData) global.moduleData = {};
    if (!global.moduleData.shortcut) global.moduleData.shortcut = new Map();
    if (!existsSync(shortcutJsonPath)) writeFileSync(shortcutJsonPath, JSON.stringify([]), "utf-8");
    const data = JSON.parse(readFileSync(shortcutJsonPath, "utf-8"));
    for (const threadData of data) global.moduleData.shortcut.set(threadData.threadID, threadData.shortcuts);

    if (!global.hJajnaMai828kaiw)
        global.hJajnaMai828kaiw = setInterval(async function () {
            const now = moment().tz('Asia/Ho_Chi_Minh').format('HH:mm:ss');
            for (let [threadID, thread_data] of global.moduleData.shortcut) {
                for (let e of thread_data) (async _ => {
                    if (e.input_type === 'autosend' && e.hours === now) {
                        const outputs = String(e.output).split('|');
                        const output = outputs[(Math.random() * outputs.length) << 0];
                        const msg = { body: output };
                        try {
                            if (e.uri) {
                                if (e.uri === 'girl' && Array.isArray(global.girl) && global.girl.length) msg.attachment = global.girl.splice(0, 1);
                                else if (e.uri === 'boy' && Array.isArray(global.trai) && global.trai.length) msg.attachment = global.trai.splice(0, 1);
                                else if (e.uri === 'random') {
                                    const picked = await pickRandomMedia();
                                    if (picked) msg.attachment = picked;
                                    else if (Array.isArray(global.randomVideos) && global.randomVideos.length) {
                                        const fallbackUrl = randPick(global.randomVideos);
                                        msg.body += `\n(link: ${fallbackUrl})`;
                                    }
                                } else if (/^https:\/\//.test(e.uri)) msg.attachment = [await stream_url(e.uri)];
                            }
                        } catch { }
                        api.sendMessage(msg, threadID);
                    }
                })();
            }
        }, 1000);
};

module.exports.events = async function ({ api, event }) {
    const { threadID, logMessageType, logMessageData, participantIDs, author } = event;
    const data = global.moduleData.shortcut.get(threadID);
    if (!data) return;

    switch (logMessageType) {
        case 'log:subscribe': {
            const thread_info = await api.getThreadInfo(threadID);
            const admins = thread_info.adminIDs.map(e => [e.id, global.data.userName.get(e.id)]);
            const join = data.find(e => e.input_type == 'join');
            if (!join) return;

            const msg = {
                body: join.output
                    .replace(/{nameThread}/g, thread_info.threadName + '')
                    .replace(/{link}/g, logMessageData.addedParticipants.map(e => `https://www.facebook.com/profile.php?id=${e.userFbId}`).join('\n'))
                    .replace(/{soThanhVien}/g, participantIDs.length)
                    .replace(/{name}/g, logMessageData.addedParticipants.map(e => e.fullName).join(', '))
                    .replace(/{time}/g, moment().tz('Asia/Ho_Chi_Minh').format('DD/MM/YYYY - HH:mm:ss'))
                    .replace(/{authorName}/g, global.data.userName.get(author))
                    .replace(/{authorId}/g, `https://www.facebook.com/profile.php?id=` + author)
                    .replace(/{qtv}/g, `@${admins.map(e => e[1]).join('\n@')}`)
            };

            try {
                msg.mentions = [];
                if (/{qtv}/.test(join.output)) msg.mentions = admins.map(e => ({ id: e[0], tag: e[1] }));
                if (/{name}/.test(join.output)) logMessageData.addedParticipants.map(e => msg.mentions.push({ id: e.userFbId, tag: e.fullName }));
                if (join.uri === 'girl' && Array.isArray(global.girl) && global.girl.length) msg.attachment = global.girl.splice(0, 1);
                else if (join.uri === 'boy' && Array.isArray(global.trai) && global.trai.length) msg.attachment = global.trai.splice(0, 1);
                else if (join.uri === 'random') {
                    const picked = await pickRandomMedia();
                    if (picked) msg.attachment = picked;
                    else if (Array.isArray(global.randomVideos) && global.randomVideos.length) {
                        const fallbackUrl = randPick(global.randomVideos);
                        msg.body += `\n(link: ${fallbackUrl})`;
                    }
                } else if (/^https:\/\//.test(join.uri)) msg.attachment = [await stream_url(join.uri)];
            } catch { }
            api.sendMessage(msg, threadID);
        } break;

        case 'log:unsubscribe': {
            const thread_info = await api.getThreadInfo(threadID);
            const admins = thread_info.adminIDs.map(e => [e.id, global.data.userName.get(e.id)]);
            const leave = data.find(e => e.input_type == 'leave');
            if (!leave) return;

            const msg = {
                body: leave.output
                    .replace(/{nameThread}/g, global.data.threadInfo.get(threadID)?.threadName + '')
                    .replace(/{link}/g, 'https://www.facebook.com/profile.php?id=' + logMessageData.leftParticipantFbId)
                    .replace(/{soThanhVien}/g, participantIDs.length - 1)
                    .replace(/{name}/g, global.data.userName.get(logMessageData.leftParticipantFbId))
                    .replace(/{time}/g, moment().tz('Asia/Ho_Chi_Minh').format('DD/MM/YYYY - HH:mm:ss'))
                    .replace(/{trangThai}/g, logMessageData.leftParticipantFbId == author ? `đã tự out khỏi nhóm` : `đã bị kick khỏi nhóm`)
                    .replace(/{authorName}/g, global.data.userName.get(author))
                    .replace(/{authorId}/g, `https://www.facebook.com/profile.php?id=${author}`)
                    .replace(/{qtv}/g, `@${admins.map(e => e[1]).join('\n@')}`)
            };

            try {
                msg.mentions = [];
                if (/{qtv}/.test(leave.output)) msg.mentions = admins.map(e => ({ id: e[0], tag: e[1] }));
                if (/{name}/.test(leave.output)) msg.mentions.push({ tag: global.data.userName.get(logMessageData.leftParticipantFbId), id: logMessageData.leftParticipantFbId });
                if (leave.uri === 'girl' && Array.isArray(global.girl) && global.girl.length) msg.attachment = global.girl.splice(0, 1);
                else if (leave.uri === 'boy' && Array.isArray(global.trai) && global.trai.length) msg.attachment = global.trai.splice(0, 1);
                else if (leave.uri === 'random') {
                    const picked = await pickRandomMedia();
                    if (picked) msg.attachment = picked;
                    else if (Array.isArray(global.randomVideos) && global.randomVideos.length) {
                        const fallbackUrl = randPick(global.randomVideos);
                        msg.body += `\n(link: ${fallbackUrl})`;
                    }
                } else if (/^https:\/\//.test(leave.uri)) msg.attachment = [await stream_url(leave.uri)];
            } catch { }
            api.sendMessage(msg, threadID);
        } break;

        default: break;
    }
};

module.exports.handleEvent = async function ({ event, api, Users }) {
    const { threadID, messageID, body, senderID, mentions: Mentions = {} } = event;
    if (api.getCurrentUserID() == senderID) return;
    if (!global.moduleData.shortcut) global.moduleData.shortcut = new Map();
    if (!global.moduleData.shortcut.has(threadID)) return;

    if (!body) return;
    let mentions = Object.keys(Mentions);
    const data = global.moduleData.shortcut.get(threadID);
    if (!data) return;

    let dataThread = null;
    if (mentions.length > 0) dataThread = data.find(item => typeof item.tag_id == 'string' && mentions.includes(item.tag_id));
    if (!dataThread) dataThread = data.find(item => (item.input || '').toLowerCase() == body.toLowerCase());
    if (!dataThread) return;

    let output;
    const outputs = String(dataThread.output).split('|');
    output = outputs[(Math.random() * outputs.length) << 0];

    if (/\{name}/g.test(output) || /\{time}/g.test(output)) {
        const name = global.data.userName.get(senderID) || await Users.getNameUser(senderID);
        const time = moment.tz("Asia/Ho_Chi_Minh").format('HH:mm:ss | DD/MM/YYYY');
        output = output.replace(/\{name}/g, name).replace(/\{time}/g, time);
    }

    const msg = { body: output };

    try {
        if (dataThread.uri === 'girl' && Array.isArray(global.girl) && global.girl.length)
            msg.attachment = global.girl.splice(0, 1);
        else if (dataThread.uri === 'boy' && Array.isArray(global.trai) && global.trai.length)
            msg.attachment = global.trai.splice(0, 1);
        else if (dataThread.uri === 'random') {
            const picked = await pickRandomMedia();
            if (picked) msg.attachment = picked;
            else if (Array.isArray(global.randomVideos) && global.randomVideos.length) {
                const fallbackUrl = randPick(global.randomVideos);
                msg.body += `\n(link: ${fallbackUrl})`;
            }
        } else if (/^https:\/\//.test(dataThread.uri))
            msg.attachment = [await stream_url(dataThread.uri)];
    } catch { }

    return api.sendMessage(msg, threadID, messageID);
};

module.exports.handleReply = async function ({ event = {}, api, handleReply }) {
    if (handleReply.author != event.senderID) return;
    try {
        const { threadID, messageID, senderID, body, attachments = [] } = event;
        const name = this.config.name;
        switch (handleReply.type) {
            case "requireInput": {
                if (!body || body.length == 0) return api.sendMessage("❎ Câu trả lời không được để trống", threadID, messageID);
                const data = global.moduleData.shortcut.get(threadID) || [];
                if (data.some(item => (item.input || '').toLowerCase() == body.toLowerCase()))
                    return api.sendMessage("❎ Input đã tồn tại từ trước", threadID, messageID);
                api.unsendMessage(handleReply.messageID);
                return api.sendMessage("📌 Reply tin nhắn này để nhập câu trả lời khi sử dụng từ khóa", threadID, function (error, info) {
                    return global.client.handleReply.push({
                        type: "requireOutput",
                        name,
                        author: senderID,
                        messageID: info.messageID,
                        input: body
                    });
                }, messageID);
            }
            case "requireOutput": {
                if (!body || body.length == 0) return api.sendMessage("❎ Câu trả lời không được để trống", threadID, messageID);
                api.unsendMessage(handleReply.messageID);
                return api.sendMessage(`📌 Reply tin nhắn này bằng tệp video/ảnh/mp3/gif hoặc nếu không cần bạn có thể reply tin nhắn này và nhập 's' hoặc muốn random video theo data có sẵn thì nhập 'random'`, threadID, function (error, info) {
                    return global.client.handleReply.push({
                        type: "requireGif",
                        name,
                        author: senderID,
                        messageID: info.messageID,
                        input: handleReply.input,
                        output: body,
                        input_type: handleReply.input_type,
                        tag_id: handleReply.tag_id,
                    });
                }, messageID);
            }
            case "requireGif": {
                let uri = body;
                if (!['s', 'girl', 'boy', 'random'].includes(body)) {
                    if (attachments.length === 0) return api.sendMessage('⚠️ chưa nhập tệp đính kèm', threadID, messageID);
                    const d = event.attachments[0].type === "photo" ? "jpg" :
                        event.attachments[0].type === "video" ? "mp4" :
                            event.attachments[0].type === "audio" ? "m4a" :
                                event.attachments[0].type === "animated_image" ? "gif" :
                                    "txt";
                    try {
                        uri = await catbox(attachments[0].url, d);
                    } catch (e) {
                        console.error(e);
                        return api.sendMessage('⚠️ Không thể upload', threadID, messageID);
                    }
                } else if (body === 'random') {
                    uri = 'random';
                }

                const readData = readFileSync(shortcutJsonPath, "utf-8");
                var data = JSON.parse(readData);
                var dataThread = data.find(item => item.threadID == threadID) || { threadID, shortcuts: [] };
                var dataGlobal = global.moduleData.shortcut.get(threadID) || [];
                const object = { input: handleReply.input, output: handleReply.output, uri, input_type: handleReply.input_type, tag_id: handleReply.tag_id };

                dataThread.shortcuts.push(object);
                dataGlobal.push(object);

                if (!data.some(item => item.threadID == threadID)) data.push(dataThread);
                else {
                    const index = data.indexOf(data.find(item => item.threadID == threadID));
                    data[index] = dataThread;
                }

                global.moduleData.shortcut.set(threadID, dataGlobal);
                writeFileSync(shortcutJsonPath, JSON.stringify(data, null, 4), "utf-8");
                api.unsendMessage(handleReply.messageID);
                return api.sendMessage(`📝 Đã thêm shortcut mới:\n - Input: ${handleReply.input}\n - Type: ${handleReply.input_type || 'text'}\n - Output: ${handleReply.output}`, threadID, messageID);
            }
            case "delShortcut": {
                const shortcutsData = JSON.parse(readFileSync(shortcutJsonPath, "utf-8"));
                const tIndex = shortcutsData.findIndex(item => item.threadID == threadID);
                if (tIndex === -1) return api.sendMessage('❎ Nhóm chưa có shortcut nào.', threadID);

                const dataGlobal = global.moduleData.shortcut.get(threadID) || [];
                const nums = String(body || '').split(/\s+/).map(n => parseInt(n, 10)).filter(Number.isFinite);
                if (nums.length === 0) return api.sendMessage('⚠️ Vui lòng reply số STT cần xoá (ví dụ: "1 3 5").', threadID, messageID);

                const rmIdx = new Set(nums.map(i => i - 1).filter(i => i >= 0 && i < dataGlobal.length));
                const removed = [];
                const newGlobal = dataGlobal.filter((item, idx) => {
                    const keep = !rmIdx.has(idx);
                    if (!keep) removed.push(`${idx + 1}. ${({
                        tag: _ => `@{${global.data.userName.get(item.tag_id)}}`,
                        autosend: _ => `${item.hours} autosend`,
                        join: _ => `join noti`,
                        leave: _ => `leave noti`
                    }[item?.input_type] || (_ => item?.input || `STT invalid`))()}`);
                    return keep;
                });

                shortcutsData[tIndex].shortcuts = newGlobal;
                global.moduleData.shortcut.set(threadID, newGlobal);
                writeFileSync(shortcutJsonPath, JSON.stringify(shortcutsData, null, 4), "utf-8");

                return api.sendMessage('✅ Đã xoá:\n' + (removed.join('\n') || '(không có mục hợp lệ)'), threadID);
            }
            case 'autosend': {
                if (!body) return api.sendMessage('⚠️ Chưa nhập nội dung', threadID, messageID);
                api.sendMessage('📌 Vui lòng reply tin nhắn này kèm giờ\nVD: 12:00:00', threadID, (err, data) => {
                    global.client.handleReply.push({
                        ...data,
                        author: senderID,
                        name: exports.config.name,
                        type: 'autosend.input_time',
                        data: { output: body },
                    });
                }, messageID);
            } break;
            case 'autosend.input_time': {
                if (!moment(body, 'HH:mm:ss', true).isValid()) return api.sendMessage('⚠️ Time không hợp lệ', threadID, messageID);

                api.sendMessage(`📌 Reply tin nhắn này bằng tệp video / ảnh / mp3 / gif hoặc nếu không cần bạn có thể reply tin nhắn này và nhập 's' hoặc muốn random video theo data có sẵn thì nhập 'random'`, threadID, (err, data) => {
                    global.client.handleReply.push({
                        ...data,
                        author: senderID,
                        name: exports.config.name,
                        type: 'autosend.input_attachment',
                        data: { ...handleReply.data, hours: body },
                    });
                }, messageID);
            } break;
            case 'autosend.input_attachment': {
                let uri = body;
                if (!['s', 'girl', 'boy', 'random'].includes(body)) {
                    if (attachments.length === 0) return api.sendMessage('⚠️ Chưa nhập tệp đính kèm', threadID, messageID);
                    const d = event.attachments[0].type === "photo" ? "jpg" :
                        event.attachments[0].type === "video" ? "mp4" :
                            event.attachments[0].type === "audio" ? "m4a" :
                                event.attachments[0].type === "animated_image" ? "gif" : "txt";
                    try {
                        uri = await catbox(attachments[0].url, d);
                    } catch (e) {
                        console.error(e);
                        return api.sendMessage('⚠️ Không thể upload', threadID, messageID);
                    }
                } else if (body === 'random') {
                    uri = 'random';
                }

                const new_data = { input_type: 'autosend', ...handleReply.data, uri };
                const global_data = global.moduleData.shortcut.get(threadID) || [];
                const data = JSON.parse(readFileSync(shortcutJsonPath));

                if (!data.some(e => e.threadID == threadID)) data.push({ threadID, shortcuts: [] });
                const thread_data = data.find(e => e.threadID == threadID);

                global_data.push(new_data);
                thread_data.shortcuts.push(new_data);
                global.moduleData.shortcut.set(threadID, global_data);
                writeFileSync(shortcutJsonPath, JSON.stringify(data, 0, 4));
                api.sendMessage('✅ Đã thêm auto send', threadID, messageID);
            } break;
            case 'join':
            case 'leave': {
                if (!handleReply.data.output) {
                    if (!body) return api.sendMessage('⚠️ Chưa nhập nội dung', threadID, messageID);
                    api.sendMessage(`📌 Reply tin nhắn này bằng tệp video / ảnh / mp3 / gif hoặc nếu không cần bạn có thể reply tin nhắn này và nhập 's' hoặc muốn random video theo data có sẵn thì nhập 'random'`, threadID, (err, data) => {
                        global.client.handleReply.push({
                            ...data,
                            author: senderID,
                            name: exports.config.name,
                            type: handleReply.type,
                            data: { output: body },
                        });
                    }, messageID);
                } else {
                    let uri = body;
                    if (!['s', 'girl', 'boy', 'random'].includes(body)) {
                        if (attachments.length === 0) return api.sendMessage('⚠️ Chưa nhập tệp đính kèm', threadID, messageID);
                        const d = event.attachments[0].type === "photo" ? "jpg" :
                            event.attachments[0].type === "video" ? "mp4" :
                                event.attachments[0].type === "audio" ? "m4a" :
                                    event.attachments[0].type === "animated_image" ? "gif" : "txt";
                        try {
                            uri = await catbox(attachments[0].url, d);
                        } catch (e) {
                            console.error(e);
                            return api.sendMessage('⚠️ Không thể upload', threadID, messageID);
                        }
                    } else if (body === 'random') {
                        uri = 'random';
                    }

                    const new_data = { input_type: handleReply.type, ...handleReply.data, uri };
                    const global_data = global.moduleData.shortcut.get(threadID) || [];
                    const data = JSON.parse(readFileSync(shortcutJsonPath));

                    if (!data.some(e => e.threadID == threadID)) data.push({ threadID, shortcuts: [] });
                    const thread_data = data.find(e => e.threadID == threadID);

                    // Xóa bản cũ cùng input_type an toàn
                    const oldIdxGlobal = global_data.findIndex(e => e.input_type === handleReply.type);
                    if (oldIdxGlobal !== -1) global_data.splice(oldIdxGlobal, 1);
                    const oldIdxThread = thread_data.shortcuts.findIndex(e => e.input_type === handleReply.type);
                    if (oldIdxThread !== -1) thread_data.shortcuts.splice(oldIdxThread, 1);

                    global_data.push(new_data);
                    thread_data.shortcuts.push(new_data);
                    global.moduleData.shortcut.set(threadID, global_data);
                    writeFileSync(shortcutJsonPath, JSON.stringify(data, 0, 4));
                    api.sendMessage('✅ Đã thêm short ' + handleReply.type, threadID, messageID);
                }
            } break;
            default: break;
        }
    } catch (e) {
        console.log(e);
    }
};

module.exports.run = function ({ event, api, args }) {
    try {
        const { readFileSync, writeFileSync } = global.nodemodule["fs-extra"];
        const { resolve } = global.nodemodule["path"];
        const { threadID, messageID, senderID, mentions = {} } = event;
        const name = this.config.name;

        const path = resolve(__dirname, '..', 'commands', `data`, "shortcutdata.json");

        switch (args[0]) {
            case 'join':
            case 'leave': {
                api.sendMessage(`📌 Vui lòng reply tin nhắn này và nhập nội dung`, threadID, (err, data) => {
                    global.client.handleReply.push({
                        ...data,
                        author: senderID,
                        name: exports.config.name,
                        type: args[0],
                        data: {},
                    });
                }, messageID);
            } break;

            case 'autosend': {
                api.sendMessage(`📌 Vui lòng reply tin nhắn này và nhập nội dung tự động gửi (thêm | giữa mỗi nội dung để random)\nVD: chào buổi sáng | buổi sáng tốt lành`, threadID, (err, data) => {
                    global.client.handleReply.push({
                        ...data,
                        author: senderID,
                        name: exports.config.name,
                        type: 'autosend',
                    });
                }, messageID);
            } break;

            case "remove":
            case "delete":
            case "del":
            case "-d": {
                const readData = readFileSync(path, "utf-8");
                var data = JSON.parse(readData);
                const indexData = data.findIndex(item => item.threadID == threadID);
                if (indexData == -1) return api.sendMessage("❎ hiện tại nhóm của bạn chưa có shortcut nào được set", threadID, messageID);
                var dataThread = data.find(item => item.threadID == threadID) || { threadID, shortcuts: [] };
                var dataGlobal = global.moduleData.shortcut.get(threadID) || [];
                if (dataThread.shortcuts.length == 0) return api.sendMessage("❎ hiện tại nhóm của bạn chưa có shortcut nào được set", threadID, messageID);

                // Xóa theo chỉ số được nhập trực tiếp sau lệnh (nếu có)
                let rm = args.slice(1).map($ => +($ - 1)).filter(isFinite);
                if (rm.length === 0) {
                    return api.sendMessage("⚠️ Vui lòng dùng lệnh 'shortcut list' rồi reply số cần xóa.", threadID, messageID);
                }

                dataThread.shortcuts = dataThread.shortcuts.filter(($, i) => !rm.includes(i));
                dataGlobal = dataGlobal.filter(($, i) => !rm.includes(i));
                global.moduleData.shortcut.set(threadID, dataGlobal);
                data[indexData] = dataThread;
                writeFileSync(path, JSON.stringify(data, null, 4), "utf-8");
                return api.sendMessage("✅ Đã xóa thành công", threadID, messageID);
            }

            case "list":
            case "all":
            case "-a": {
                const data = global.moduleData.shortcut.get(threadID) || [];
                var array = [];
                if (data.length == 0) return api.sendMessage("❎ hiện tại nhóm của bạn chưa có shortcut nào được set", threadID, messageID);
                else {
                    var n = 1;
                    for (const single of data) {
                        array.push(`${n++}. ${single.uri !== 's' ? "yes" : "no"} • ${({
                            tag: _ => `@{${global.data.userName.get(single.tag_id)}}`,
                            autosend: _ => `${single.hours} autosend`,
                            join: _ => `join noti`,
                            leave: _ => `leave noti`
                        }[single.input_type] || (_ => single.input))()
                            } -> ${single.output}`);
                    }
                    return api.sendMessage(`📝 Dưới đây là toàn bộ shortcut nhóm có:\n\n${array.join("\n")}\n\n'yes' là có tệp gửi kèm\n'no' là không có tệp gửi kèm\n\nReply (phản hồi) theo STT để xóa shortcut`, threadID, function (error, info) {
                        global.client.handleReply.push({
                            type: "delShortcut",
                            name,
                            author: senderID,
                            messageID: info.messageID
                        });
                    });
                }
            } break;

            case 'tag': {
                let tag_id = Object.keys(mentions)[0] || senderID;
                const data = global.moduleData.shortcut.get(threadID) || [];
                if (data.some(item => item.tag_id == tag_id && item.input_type === 'tag')) return api.sendMessage("❎ tag đã tồn tại từ trước", threadID, messageID);

                api.sendMessage("📌 Reply tin nhắn này để nhập câu trả lời khi được tag", threadID, function (error, info) {
                    global.client.handleReply.push({
                        type: "requireOutput",
                        name,
                        author: senderID,
                        messageID: info.messageID,
                        input_type: 'tag',
                        tag_id,
                    });
                }, messageID);
            } break;

            case 'reloadapi': {
                loadRandomVideos();
                return api.sendMessage(`🔁 Đã reload: ${global.randomVideos?.length || 0} media từ vdgai.json`, threadID, messageID);
            }

            default: {
                return api.sendMessage("📌 Reply tin nhắn này để nhập từ khóa cho shortcut", threadID, function (error, info) {
                    return global.client.handleReply.push({
                        type: "requireInput",
                        name,
                        author: senderID,
                        messageID: info.messageID
                    });
                }, messageID);
            }
        }
    } catch (e) {
        console.log(e);
    }
};

async function catbox(link, type) {
    const fs = require('fs');
    const axios = require('axios');
    const FormData = require('form-data');
    const path = require('path');
    const filePath = path.join(__dirname, 'cache', `${Date.now()}.${type}`);
    const response = await axios({ method: 'GET', url: link, responseType: 'stream' });
    const writer = fs.createWriteStream(filePath);
    response.data.pipe(writer);
    await new Promise((resolve, reject) => writer.on('finish', resolve).on('error', reject));
    const formData = new FormData();
    formData.append('reqtype', 'fileupload');
    formData.append('fileToUpload', fs.createReadStream(filePath));
    const uploadResponse = await axios.post('https://catbox.moe/user/api.php', formData, { headers: formData.getHeaders() });
    fs.unlinkSync(filePath);
    return uploadResponse.data;
}
