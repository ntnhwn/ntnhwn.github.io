this.config = {
    name: "restart",
    version: "1.0.0",
    hasPermssion: 3,
    credits: "Kaori Waguri",
    description: "Khởi Động Lại Bot.",
    commandCategory: "Hệ thống",
    cooldowns: 0,
    images: [],
 };
 this.run = ({event, api}) => api.sendMessage("✅", event.threadID, () => process.exit(1), event.messageID)