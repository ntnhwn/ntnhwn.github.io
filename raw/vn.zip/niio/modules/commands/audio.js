const axios = require("axios");
const ytSearch = require("yt-search");

module.exports.config = {
  name: "audio",
  version: "3.3.0",
  hasPermssion: 0,
  credits: "Priyanshi Kaur, LocDev",
  description: "Phát audio/video YouTube (TheOne API)",
  commandCategory: "Tiện ích",
  usages: "sing <tên bài hoặc YouTube URL> [audio|video]",
  cooldowns: 5,
  dependencies: {
    "axios": "",
    "yt-search": ""
  }
};

module.exports.languages = {
  vi: {
    missingInput: "❗ Vui lòng nhập tên bài hát hoặc liên kết YouTube.",
    searching: "🔎 Đang tìm \"%1\"...",
    notFound: "❌ Không tìm thấy kết quả YouTube phù hợp.",
    fetching: "⬇️ Đang tải %1...\n📀 %2",
    result: "🎶 %1\n📺 %2\n📦 Chất lượng: %3\n⌛ Hết hạn: %4\n\n⏱️ API: %5ms\n⏳ Tổng: %6ms",
    failed: "❌ Thất bại: %1"
  },
  en: {
    missingInput: "❗ Please provide a song name or YouTube link.",
    searching: "🔎 Searching \"%1\"...",
    notFound: "❌ No YouTube results found.",
    fetching: "⬇️ Fetching %1...\n📀 %2",
    result: "🎶 %1\n📺 %2\n📦 Quality: %3\n⌛ Expiration: %4\n\n⏱️ API: %5ms\n⏳ Total: %6ms",
    failed: "❌ Failed: %1"
  }
};

module.exports.run = async function ({ api, event, args, getText }) {
  const { threadID, messageID } = event;
  const startedAt = Date.now();

  let type = "audio";
  if (args.length > 1 && ["audio", "video"].includes(String(args[args.length - 1]).toLowerCase())) {
    type = args.pop().toLowerCase();
  }

  const songName = args.join(" ");
  if (!songName) return api.sendMessage(getText('missingInput'), threadID, messageID);

  try {
    if (typeof api.setMessageReaction === 'function') {
      api.setMessageReaction("🔍", messageID, () => { }, true);
    }
    const processing = await new Promise(resolve => api.sendMessage(getText('searching', songName), threadID, (e, info) => resolve(info)));

    let videoUrl;
    if (/^https?:\/\//i.test(songName)) {
      videoUrl = songName;
    } else {
      const results = await ytSearch(songName);
      if (!results || !Array.isArray(results.videos) || results.videos.length === 0) {
        await api.unsendMessage(processing.messageID);
        return api.sendMessage(getText('notFound'), threadID, messageID);
      }
      videoUrl = `https://youtu.be/${results.videos[0].videoId}`;
    }

    const base = "http://theone-api-3416.ddnsgeek.com:3040";
    const apiUrl = `${base}/?url=${encodeURIComponent(videoUrl)}&format=${type === 'audio' ? 'm4a' : 'mp4'}${type === 'video' ? '&quality=480p' : ''}`;

    const apiStart = Date.now();
    const res = await axios.get(apiUrl);
    const apiMs = Date.now() - apiStart;

    const data = res.data || {};
    if (data.status !== 'ok' || !data.downloadLink) {
      await api.unsendMessage(processing.messageID);
      return api.sendMessage(getText('failed', 'Fetch media info failed'), threadID, messageID);
    }

    await new Promise(resolve => api.sendMessage(getText('fetching', type, data.title), threadID, () => resolve()));

    const stream = await global.utils.streamUrl(data.downloadLink);
    await api.unsendMessage(processing.messageID);

    const totalMs = Date.now() - startedAt;

    return api.sendMessage({
      body: getText('result', data.title || '-', data.channel || '-', data.quality || '-', data.expiration || '-', apiMs.toFixed ? apiMs.toFixed(0) : apiMs, totalMs.toFixed ? totalMs.toFixed(0) : totalMs),
      attachment: stream
    }, threadID, (err) => {
      if (typeof api.setMessageReaction === 'function') {
        api.setMessageReaction(err ? "❌" : "✅", messageID, () => { }, true);
      }
    });
  } catch (err) {
    try { await api.setMessageReaction && api.setMessageReaction("❌", messageID, () => { }, true); } catch {}
    return api.sendMessage(getText('failed', err.message || err), threadID, messageID);
  }
};

