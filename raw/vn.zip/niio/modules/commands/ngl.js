const axios = require('axios');

module.exports.config = {
  name: "ngl",
  version: "2.0.0",
  hasPermssion: 2,
  credits: "Kim Joseph DG Bien - fix by Văn Hưng",
  description: "Spam tin nhắn ẩn danh đến tài khoản NGL",
  usePrefix: true,
  commandCategory: "Tiện ích",
  usages: "ngl user_name | nội dung | số_lần",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, args }) {
  const input = args.join(" ");
  const parts = input.split("|").map(item => item.trim());

  if (parts.length !== 3) {
    return api.sendMessage("⚠️ Sai cú pháp!\n👉 Dùng: ngl user_name | nội dung | số_lần", event.threadID, event.messageID);
  }

  const [username, message, amountStr] = parts;
  const amount = parseInt(amountStr);

  if (!username || !message || isNaN(amount) || amount <= 0) {
    return api.sendMessage("❌ Vui lòng nhập đúng định dạng:\nspamngl user_name | nội dung | số_lần", event.threadID, event.messageID);
  }

  const headers = {
    'referer': `https://ngl.link/${username}`,
    'accept-language': 'en-US,en;q=0.9'
  };

  const payload = {
    username: username,
    question: message,
    deviceId: 'ea356443-ab18-4a49-b590-bd8f96b994ee',
    gameSlug: '',
    referrer: ''
  };

  let success = 0;
  let fail = 0;

  api.sendMessage(`⏳ Đang gửi ${amount} tin nhắn đến @${username}...`, event.threadID);

  for (let i = 1; i <= amount; i++) {
    try {
      const res = await axios.post("https://ngl.link/api/submit", payload, { headers });
      if (res.status === 200) {
        success++;
      } else {
        fail++;
      }
      await new Promise(r => setTimeout(r, 500)); // delay nhẹ
    } catch (e) {
      fail++;
      await new Promise(r => setTimeout(r, 500)); // delay giữa các lần retry
    }
  }

  api.sendMessage(
    `📨 Đã gửi hoàn tất!\n👤 User: ${username}\n📝 Nội dung: ${message}\n✅ Thành công: ${success}\n❌ Thất bại: ${fail}`,
    event.threadID
  );
};