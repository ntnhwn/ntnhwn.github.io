module.exports.config = {
    name: "syncdata",
    version: "1.0.0",
    hasPermssion: 2,
    credits: "Kaori Waguri",
    description: "🔄 Đồng bộ và cập nhật lại dữ liệu từ Facebook (fix lỗi số nhóm sai)",
    commandCategory: "Hệ thống",
    usages: "[threads/users/all]",
    cooldowns: 3
};

module.exports.run = async ({ api, event, args, Threads, Users, Currencies }) => {
    const { threadID, messageID } = event;
    
    const option = args[0] ? args[0].toLowerCase() : "all";
    
    if (!["threads", "users", "all"].includes(option)) {
        return api.sendMessage(
            "📋 SYNC DATA - ĐỒNG BỘ DỮ LIỆU\n" +
            "══════════════\n\n" +
            "📝 Cách sử dụng:\n" +
            "• n.syncdata threads - Đồng bộ dữ liệu nhóm\n" +
            "• n.syncdata users - Đồng bộ dữ liệu người dùng\n" +
            "• n.syncdata all - Đồng bộ tất cả\n\n" +
            "🎯 Mục đích:\n" +
            "• Fix lỗi số nhóm không đúng (VD: 32 nhóm nhưng thực tế chỉ 6)\n" +
            "• Cập nhật thông tin mới nhất từ Facebook\n" +
            "• Xóa dữ liệu nhóm/người dùng không còn tồn tại",
            threadID, messageID
        );
    }
    
    try {
        api.sendMessage(
            `🔄 ĐANG ĐỒNG BỘ DỮ LIỆU${option === 'all' ? ' (TOÀN BỘ)' : ` (${option.toUpperCase()})`}...\n\n` +
            "⏳ Quá trình này có thể mất vài phút...\n" +
            "📊 Đang kiểm tra dữ liệu từ Facebook...",
            threadID, async (err, info) => {
                try {
                    const startTime = Date.now();
                    const stats = {
                        threadsRemoved: 0,
                        threadsUpdated: 0,
                        threadsAdded: 0,
                        usersRemoved: 0,
                        usersUpdated: 0,
                        usersAdded: 0
                    };
                    
                    if (option === "threads" || option === "all") {
                        const result = await syncThreads(api, Threads);
                        Object.assign(stats, result);
                    }
                    
                    if (option === "users" || option === "all") {
                        const result = await syncUsers(api, Users, Threads);
                        Object.assign(stats, result);
                    }
                    
                    const executionTime = ((Date.now() - startTime) / 1000).toFixed(2);
                    
                    let message = "✅ ĐỒNG BỘ DỮ LIỆU THÀNH CÔNG!\n" +
                        "══════════════\n\n";
                    
                    if (option === "threads" || option === "all") {
                        message += "📦 THREADS (NHÓM/ĐOẠN CHAT):\n" +
                            `• ❌ Đã xóa: ${stats.threadsRemoved} (không tồn tại)\n` +
                            `• 🔄 Đã cập nhật: ${stats.threadsUpdated}\n` +
                            `• ✨ Đã thêm mới: ${stats.threadsAdded}\n\n`;
                    }
                    
                    if (option === "users" || option === "all") {
                        message += "👥 USERS (NGƯỜI DÙNG):\n" +
                            `• ❌ Đã xóa: ${stats.usersRemoved} (không tồn tại)\n` +
                            `• 🔄 Đã cập nhật: ${stats.usersUpdated}\n` +
                            `• ✨ Đã thêm mới: ${stats.usersAdded}\n\n`;
                    }
                    
                    message += `⏱️ Thời gian: ${executionTime}s\n\n` +
                        "🎯 Dữ liệu đã được đồng bộ với Facebook!";
                    
                    return api.sendMessage(message, threadID, info.messageID);
                    
                } catch (error) {
                    console.error("Sync data error:", error);
                    return api.sendMessage(
                        `❌ Lỗi khi đồng bộ dữ liệu!\n\n` +
                        `🔍 Chi tiết: ${error.message}\n\n` +
                        `💡 Gợi ý:\n` +
                        `• Kiểm tra kết nối Facebook\n` +
                        `• Thử lại sau vài phút\n` +
                        `• Liên hệ admin nếu lỗi lặp lại`,
                        threadID, info.messageID
                    );
                }
            }
        );
        
    } catch (error) {
        console.error("Sync data error:", error);
        return api.sendMessage(
            `❌ Lỗi hệ thống!\n\n` +
            `🔍 Chi tiết: ${error.message}`,
            threadID, messageID
        );
    }
};

async function syncThreads(api, Threads) {
    const stats = {
        threadsRemoved: 0,
        threadsUpdated: 0,
        threadsAdded: 0
    };
    
    console.log("🔄 Starting thread sync...");
    
    let actualThreads = [];
    try {
        const threadList = await api.getThreadList(100, null, ["INBOX"]);
        actualThreads = threadList.map(t => t.threadID);
        console.log(`📊 Found ${actualThreads.length} actual threads from Facebook`);
    } catch (error) {
        console.error("Error getting thread list:", error);
        throw new Error("Không thể lấy danh sách nhóm từ Facebook");
    }
    
    const dbThreads = await Threads.getAll();
    console.log(`📊 Found ${dbThreads.length} threads in database`);
    
    for (const dbThread of dbThreads) {
        if (!actualThreads.includes(dbThread.threadID)) {
            console.log(`❌ Removing thread ${dbThread.threadID} (not in actual list)`);
            await Threads.delData(dbThread.threadID);
            stats.threadsRemoved++;
            
            if (global.data.allThreadID) {
                const index = global.data.allThreadID.indexOf(dbThread.threadID);
                if (index > -1) global.data.allThreadID.splice(index, 1);
            }
            if (global.data.threadInfo) {
                global.data.threadInfo.delete(dbThread.threadID);
            }
            if (global.data.threadData) {
                global.data.threadData.delete(dbThread.threadID);
            }
        } else {
            try {
                const threadInfo = await api.getThreadInfo(dbThread.threadID);
                await Threads.setData(dbThread.threadID, {
                    threadInfo: JSON.stringify(threadInfo)
                });
                stats.threadsUpdated++;
                console.log(`✅ Updated thread ${dbThread.threadID}`);
            } catch (error) {
                console.error(`Error updating thread ${dbThread.threadID}:`, error.message);
            }
        }
    }
    
    for (const actualThreadID of actualThreads) {
        const existsInDB = dbThreads.some(t => t.threadID === actualThreadID);
        if (!existsInDB) {
            try {
                const threadInfo = await api.getThreadInfo(actualThreadID);
                await Threads.createData(actualThreadID, {
                    threadInfo: JSON.stringify(threadInfo)
                });
                stats.threadsAdded++;
                console.log(`✨ Added new thread ${actualThreadID}`);
                
                if (global.data.allThreadID && !global.data.allThreadID.includes(actualThreadID)) {
                    global.data.allThreadID.push(actualThreadID);
                }
            } catch (error) {
                console.error(`Error adding thread ${actualThreadID}:`, error.message);
            }
        }
    }
    
    console.log(`✅ Thread sync completed: -${stats.threadsRemoved}, ~${stats.threadsUpdated}, +${stats.threadsAdded}`);
    return stats;
}

async function syncUsers(api, Users, Threads) {
    const stats = {
        usersRemoved: 0,
        usersUpdated: 0,
        usersAdded: 0
    };
    
    console.log("🔄 Starting user sync...");
    
    const actualUsers = new Set();
    
    try {
        const threadList = await api.getThreadList(100, null, ["INBOX"]);
        
        for (const thread of threadList) {
            try {
                const threadInfo = await api.getThreadInfo(thread.threadID);
                
                if (threadInfo.participantIDs) {
                    threadInfo.participantIDs.forEach(uid => actualUsers.add(uid));
                }
                
                if (threadInfo.adminIDs) {
                    threadInfo.adminIDs.forEach(admin => {
                        if (admin.id) actualUsers.add(admin.id);
                    });
                }
            } catch (error) {
                console.error(`Error getting thread info for ${thread.threadID}:`, error.message);
            }
        }
        
        console.log(`📊 Found ${actualUsers.size} actual users from all threads`);
    } catch (error) {
        console.error("Error getting user list:", error);
        throw new Error("Không thể lấy danh sách người dùng từ Facebook");
    }
    
    const dbUsers = await Users.getAll();
    console.log(`📊 Found ${dbUsers.length} users in database`);
    
    for (const dbUser of dbUsers) {
        if (!actualUsers.has(dbUser.userID)) {
            console.log(`❌ Removing user ${dbUser.userID} (not in actual list)`);
            await Users.delData(dbUser.userID);
            stats.usersRemoved++;
            
            if (global.data.allUserID) {
                const index = global.data.allUserID.indexOf(dbUser.userID);
                if (index > -1) global.data.allUserID.splice(index, 1);
            }
            if (global.data.userName) {
                global.data.userName.delete(dbUser.userID);
            }
        } else {
            try {
                const userInfo = await api.getUserInfo(dbUser.userID);
                if (userInfo && userInfo[dbUser.userID]) {
                    const info = userInfo[dbUser.userID];
                    await Users.setData(dbUser.userID, {
                        name: info.name,
                        gender: info.gender
                    });
                    stats.usersUpdated++;
                    console.log(`✅ Updated user ${dbUser.userID}`);
                }
            } catch (error) {
                console.error(`Error updating user ${dbUser.userID}:`, error.message);
            }
        }
    }
    
    for (const actualUserID of actualUsers) {
        const existsInDB = dbUsers.some(u => u.userID === actualUserID);
        if (!existsInDB) {
            try {
                const userInfo = await api.getUserInfo(actualUserID);
                if (userInfo && userInfo[actualUserID]) {
                    const info = userInfo[actualUserID];
                    await Users.createData(actualUserID, {
                        name: info.name,
                        gender: info.gender
                    });
                    stats.usersAdded++;
                    console.log(`✨ Added new user ${actualUserID}`);
                    
                    if (global.data.allUserID && !global.data.allUserID.includes(actualUserID)) {
                        global.data.allUserID.push(actualUserID);
                    }
                }
            } catch (error) {
                console.error(`Error adding user ${actualUserID}:`, error.message);
            }
        }
    }
    
    console.log(`✅ User sync completed: -${stats.usersRemoved}, ~${stats.usersUpdated}, +${stats.usersAdded}`);
    return stats;
}
