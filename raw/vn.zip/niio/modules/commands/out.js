// out.js - Safe leave with rent check
const fs = require("fs");
const path = require("path");
const moment = require("moment-timezone");

/**
 * Resolve shared rent data file:
 * modules/commands/data/thuebot.json
 */
const dataPath = path.resolve(__dirname, "../commands/data/thuebot.json");

function readRent() {
  try {
    if (!fs.existsSync(dataPath)) return [];
    const raw = fs.readFileSync(dataPath, "utf8");
    return JSON.parse(raw || "[]");
  } catch (e) {
    return [];
  }
}

function isExpired(ddmmyyyy) {
  // hết hạn từ 00:00 của ngày HSD
  try {
    const now = moment().tz("Asia/Ho_Chi_Minh").startOf("day");
    const hsd = moment(ddmmyyyy, "DD/MM/YYYY").startOf("day");
    return now.isSameOrAfter(hsd);
  } catch (_) {
    return true;
  }
}

module.exports.config = {
  name: "out",
  version: "1.1.0",
  hasPermssion: 2,
  credits: "Sang Nguyễn • refined by ThienNhanFix",
  description: "Bot rời nhóm (tôn trọng dữ liệu thuê bot, chặn rời khi còn hạn)",
  commandCategory: "Admin",
  usages: "[tid] [force]",
  cooldowns: 3
};

module.exports.run = async function ({ api, event, args }) {
  const time = moment.tz("Asia/Ho_Chi_Minh").format("HH:mm:ss || DD/MM/YYYY");
  const input = (args[0] || "").trim();
  const force = (args[1] || "").toLowerCase() === "force" || input.toLowerCase() === "force";

  // xác định thread đích: nếu có số -> dùng; nếu không -> thread hiện tại
  const targetTID = /^\d+$/.test(input) ? input : event.threadID;

  const rentData = readRent();
  const group = rentData.find(g => String(g.t_id) === String(targetTID));

  // nếu có dữ liệu thuê và chưa hết hạn => chặn, trừ khi force
  if (group && !isExpired(group.time_end) && !force) {
    return api.sendMessage(
      `⚠️ Nhóm ${targetTID} đang trong thời gian thuê bot.\n⏳ HSD: ${group.time_end}\n` +
      `Nếu vẫn muốn rời, dùng: out ${targetTID} force`,
      event.threadID,
      event.messageID
    );
  }

  // thử báo trong box đích (nếu chính box hiện tại sẽ thấy ngay)
  const notify = `🤖 Bot rời nhóm theo lệnh Admin.\n🧾 TID: ${targetTID}\n🕒 Thời gian: ${time}`;

  // Gửi thông báo vào box đích (có thể thất bại nếu bot không còn quyền/không ở box)
  try {
    await new Promise(resolve => api.sendMessage(notify, targetTID, () => resolve()));
  } catch (_) {}

  // Thực hiện rời nhóm
  return api.removeUserFromGroup(api.getCurrentUserID(), targetTID, (err) => {
    if (err) {
      return api.sendMessage(
        `❌ Không thể rời nhóm ${targetTID}.\nLỗi: ${err.message || err}`,
        event.threadID,
        event.messageID
      );
    }
    return api.sendMessage(
      `✅ Đã rời nhóm ${targetTID} lúc ${time}${force ? " (force)" : ""}.`,
      event.threadID,
      event.messageID
    );
  });
};
